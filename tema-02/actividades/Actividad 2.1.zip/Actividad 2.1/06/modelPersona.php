<?php
    // Añadimos valores a las variables que usaremos para rellenar la tabla
    $nombre = "Daniel Alfonso";
    $apellidos = "Rodríguez Santos";
    $poblacion = "Arcos de la Frontera";
    $edad = 24;
    $ciclo = "Desarrollo Aplicaciones Web";
    $curso = "Segundo";
    $modulo = "DWES";
?>