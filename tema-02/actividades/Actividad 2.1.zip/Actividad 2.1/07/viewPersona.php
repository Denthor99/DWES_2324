<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 7</title>
</head>
<body>
    <h1>Ejercicio 7 - Historia con variables</h1>
    <p>Hola mi nombre <?= $nombre; ?>, y de apellidos <?= $apellidos; ?>. Tengo actualmente <br>
    <?= $edad; ?>, y vivo en <?= $poblacion; ?>. Estoy cursando <?= $curso; ?> de <?= $ciclo; ?>, <br>
     y estoy haciendo las actividades de <?= $modulo; ?></p>
</body>
</html>