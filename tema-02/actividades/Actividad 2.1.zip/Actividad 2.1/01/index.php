<?php
    // Titulo
    echo "<center><h1>El pais - Periodico Español</h1></center>";

    echo "<br>";

    // Parrafo de tres lineas
    echo "<h2>Roban en la casa de Sergio Ramos con sus cuatro hijos dentro durante un partido del Sevilla</h2>";
    echo "<p>La Guardia Civil ha abierto una investigación por el robo sufrido por el futbolista del Sevilla FC Sergio Ramos y su <BR>
    mujer, la presentadora Pilar Rubio, según se ha conocido este miércoles. El asalto se produjo hace una semana en su <BR>
    casa de Bollullos de la Mitación, municipio de la provincia de Sevilla, mientras se disputaba en el Sánchez Pizjuán <BR>
    el partido de Liga de Campeones entre el equipo de Ramos y el Lens francés. Por tanto, ni él ni Pilar Rubio, que ese <BR>
    día se encontraba fuera de la ciudad por motivos profesionales, se encontraban en la casa, pero sí estaban dentro sus <BR>
    cuatro hijos con las cuidadoras.</p>";

    // Enlace para acceder al periodico
    echo "<a href='http://www.elpais.es/'>EL PAIS</a>"
?>