<?php
// Creamos dos variables de tipo string
$cadena1 = "Hola que tal? <BR>";
$cadena2 = "Muy bien, tirando en la medida de los posible";

// Creamos una variable nueva y concatenamos
$cadena3 = $cadena1 . $cadena2;

//Mostramos el valor de la variable
echo $cadena3;

?>