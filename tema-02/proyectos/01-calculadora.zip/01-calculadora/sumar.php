<?php
    // Cargo el model
    include "models/suma.php";

    // Cargo la vista
    include "views/resultado.php"
?>