<?php
    // Cargo el model
    include "models/resta.php";

    // Cargo la vista
    include "views/resultado.php"
?>