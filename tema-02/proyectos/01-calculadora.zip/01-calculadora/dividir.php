<?php
    // Cargo el model
    include "models/division.php";

    // Cargo la vista
    include "views/resultado.php"
?>