<?php
    // Cargo el model
    include "models/potencia.php";

    // Cargo la vista
    include "views/resultado.php"
?>