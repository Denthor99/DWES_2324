<?php
    // Cargo el model
    include "models/multiplica.php";

    // Cargo la vista
    include "views/resultado.php"
?>