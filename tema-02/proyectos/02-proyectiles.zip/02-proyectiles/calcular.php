<?php
    // Controlador: calcular.php
    // Descripción: Realiza el cálculo de lanzamiento de proyectiles a partir
    // de los valores del formulario y muestra los resultados en la vista correspondientess
    
    // Cargo el modelo
    include "models/modelCalculadora.php";

    // Cargo la vista
    include "views/resultado.php";
?>