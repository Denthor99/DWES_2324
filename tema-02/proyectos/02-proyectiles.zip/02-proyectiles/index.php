<?php
    // Controlador: index.php
    // Descripción: cargamos el formulario de datos para el cálculo de proyectiles

    // solo nos hará falta la vista con el formulario inicials
    include "views/index.html";
?>