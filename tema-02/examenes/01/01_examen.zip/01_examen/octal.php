<?php
    /*
        Controlador: octal.php
        Descripción: controlador encargado de mostrar el resultado de la correspondiente operación
    */
    // Cargamos el modelo "modelOctal"
    include 'models/modelOctal.php';

    // Cargamos la vista correspondiente
    include 'views/viewResultado.php'

?>