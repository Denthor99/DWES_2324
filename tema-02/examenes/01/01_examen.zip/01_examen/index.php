<?php

    /*

        Controlador: index.php
        Descripción: Cargamos la vista principal, almacenda dentro de la carpeta views

    */
    # Vista
    include 'views/viewIndex.php';

?>