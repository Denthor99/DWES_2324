<?php
    /*
        Controlador: hexadecimal.php
        Descripción: controlador encargado de mostrar el resultado de la correspondiente operación
    */
    // Cargamos el modelo "modelHexadecimal"
    include 'models/modelHexadecimal.php';

    // Cargamos la vista correspondiente
    include 'views/viewResultado.php'

?>