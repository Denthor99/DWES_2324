<?php

    /*
        fichero: model.nuevo.php
        Descripción: modelo del proceso nuevo.php. 

    */

   // Cargamos las tablas correspondientes
    $peliculas = getPeliculas();
    $paises = getPaises();
    $generos = getGeneros();

    
?>