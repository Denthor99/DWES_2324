<?php

    /*
        fichero: model.index.php
        Descripción: modelo del proceso index.php

    */

    // Cargamos las tablas correspondientes
    $peliculas = getPeliculas();
    $paises = getPaises();
    $generos = getGeneros();

    
    
?>