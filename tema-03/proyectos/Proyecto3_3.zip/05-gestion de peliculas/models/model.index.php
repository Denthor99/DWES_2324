<?php

    /*
        Modelo: model.index.php
        Descripción: mostsramos una tabla con todas las películas

    */

    // Cargamos los datos de la tabla
    $peliculas = getPeliculas();
    $generos = getGeneros();
    $paises = getPaises();
    
    
?>