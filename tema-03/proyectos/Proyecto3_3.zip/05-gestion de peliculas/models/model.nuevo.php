<?php

    /*
        Modelo: model.nuevo.php
        Descripción: muestra un formulario, donde se introducirán los datos de una nueva pelicula
    */

    // Cargamos los datos de la tabla
    $peliculas = getPeliculas();
    $paises = getPaises();
    $generos = getGeneros();

   

    
?>