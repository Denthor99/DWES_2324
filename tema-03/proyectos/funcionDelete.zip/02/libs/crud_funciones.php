<?php
/*
    Funcion: eliminar()
    Descripción: elimina un elemento de la tabla
    parámetros: 
        - tabla
        - id del elemento que deseo eliminaar
    salida:
        - tabla actualizada
*/

// Buscar elemento que le corresponde id
// Sacamos los id del array, y posteriormente usamos in_array

// function eliminar(&$tabla = [], $idElemento){
//     $claves=array_keys($tabla);
//     if (in_array($idElemento,$claves)){
//         unset($tabla[$idElemento]);
//     }
// }

function eliminar(&$tabla = [], $idElemento) {
    foreach ($tabla as $indice => $elemento) {
        if ($elemento['id'] == $idElemento) {
            unset($tabla[$indice]);
            break;
        }
    }
}
?>