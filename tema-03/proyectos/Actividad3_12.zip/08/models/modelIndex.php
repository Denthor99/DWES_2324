<?php
    /*
        Modelo: modeloIndex.php
        Descripción: generamos un array con los datos de los libros (simulando una consulta a una base de datos)
    */
    
    $libros = generar_tabla();
?>