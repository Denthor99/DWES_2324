<?php
    /*
        Controlador: ordenar.php
        Descripción: ordena el contenido 
    */

    // Libreria
    include 'libs/crud_funciones.php';
    // Modelo
    include 'models/modelOrdenar.php';

    // Vista
    include 'views/viewIndex.php';

?>