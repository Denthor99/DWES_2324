<?php
     // Controlador: buscar.php
    // Descripción: filtra la tabla a partir de la expresión de búsqueda

    // Cargamos la libreria
    include 'libs/crud_funciones.php';

    // Cargamos el modelo 
    include 'models/modelBuscar.php';

    // Cargamos la vista principal
    include 'views/viewIndex.php';
?>