<?php
    // Controlador nuevo.php
    // Cargara el formulario de introducción de nuevo artículo

    // libreria
    include 'libs/crud_funciones.php';

    // añadimos el modelo donde tenemos lo datos definidos
    include 'models/modelNuevo.php';

    // cargamos la vista
    include 'views/viewNuevo.php';
?>