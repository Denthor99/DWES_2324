<?php
    /*
        Controlador: update.php
        Descripción: actualizar los datos de un artículo
    */

    // Cargaremos las librerias
    include 'libs/crud_funciones.php';

    // Cargaremos el modelo
    include 'models/modelUpdate.php';

    // Cargaremos la vista principal
    include 'views/viewIndex.php'
?>