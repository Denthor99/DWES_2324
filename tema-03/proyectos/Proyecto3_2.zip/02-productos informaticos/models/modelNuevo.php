<?php
    /*
        Modelo: modelNuevo.php
        Descripción: introducir un nuevo elemento a la tabla
    */

    // Cargamos los datos de categorias
    $categorias = generar_tabla_categorías();
?>