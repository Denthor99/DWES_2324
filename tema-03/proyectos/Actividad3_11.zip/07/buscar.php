<?php
    // Controlador: buscar.php
    // Descripción: filtra la tabla a partir de la expresión de búsqueda

    // Modelo
    include 'models/modelIndex.php';
    include 'models/modelBuscar.php';

    // solo nos hará falta la vista con el formulario inicials
    include "views/viewIndex.php";
?>