<?php
    /*
        Controlador: ordenar.php
        Descripción: ordena el contenido 
    */

    // Modelo
    include 'models/modelIndex.php';
    include 'models/modelOrdenar.php';

    // Vista
    include 'views/viewIndex.php';

?>