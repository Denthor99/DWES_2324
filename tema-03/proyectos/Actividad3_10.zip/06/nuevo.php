<?php
    // Controlador: nuevo.php
    // Descripción: Mostrar un formulario que permita añadir nuevo libro


    // Solo nos hará falta la vista con el formulario
    include "views/viewNuevo.php";
?>