<?php
# Credenciales GMAIL

# Usuario
define('USER_MAIL','');

# Clave aplicación de terceros
define('PASS_MAIL','');



?>