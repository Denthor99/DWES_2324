<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <header>
        <hgroup>
            <!-- Titulos y subtitulos -->

            <div class="container">
                <h1 class="display-7"><?php echo $__env->yieldContent('titulo'); ?></h1>
                <p class="lead"><?php echo $__env->yieldContent('subtitulo'); ?></p>
            </div>
        </hgroup>
    </header>
    <div class="container">
        <?php echo $__env->yieldContent('contenido'); ?>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    </script>
    <!-- Pié de página -->
    <footer class="footer mt-auto py-3 fixed-bottom bg-light">
        <div class="container">
            <span class="text-muted"><?php echo $__env->yieldContent('footer'); ?></span>
        </div>
    </footer>

</body>

</html><?php /**PATH C:\xampp\htdocs\DWES\tema-12\actividades\06\laravel06\resources\views/layout.blade.php ENDPATH**/ ?>