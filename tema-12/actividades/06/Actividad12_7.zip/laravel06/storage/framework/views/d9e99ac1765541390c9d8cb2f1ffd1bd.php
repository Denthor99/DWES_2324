

<?php $__env->startSection('title', 'Listado de artículos - InfoMatic'); ?>
<?php $__env->startSection('titulo', 'InfoMatic - Tu tienda Online'); ?>
<?php $__env->startSection('subtitulo', 'Listado de artículos'); ?>
<?php $__env->startSection('footer','© 2024 Daniel Alfonso Rodríguez Santos - DWES - 2º DAW - Curso 23/24'); ?>

<?php $__env->startSection('contenido'); ?>
<!-- Menú -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">InfoMatic</a>
        <div class="collapse navbar-collapse" id="navbarScroll">
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/articulos">Articulos</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Cabecera de la tabla -->
<br>
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Descripción</th>
            <th scope="col">Categoría</th>
            <th scope="col">Unidades</th>
            <th scope="col">Precio Coste</th>
            <th scope="col">Precio Venta</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($articulo['id']); ?></th>
            <td><?php echo e($articulo['descripcion']); ?></td>
            <td class="text-center"><?php echo e($articulo['categoria']); ?></td>
            <td class="text-end"><?php echo e($articulo['unidades']); ?></td>
            <td class="text-end"><?php echo e($articulo['precio_coste']); ?>€</td>
            <td class="text-end"><?php echo e($articulo['precio_venta']); ?>€</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th colspan="6">Número de articulos disponibles: <?php echo e(count($articulos)); ?></th>
        </tr>
    </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\tema-12\actividades\06\laravel06\resources\views/articulos.blade.php ENDPATH**/ ?>