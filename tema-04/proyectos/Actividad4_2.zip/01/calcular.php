<?php

    // Cargamos la clase
    include 'class/class.calculadora.php';

    // Cargamos el modelo
    include 'models/modelCalcular.php';
    
    // Cargo la vista
    include 'views/viewResultado.php';
?>