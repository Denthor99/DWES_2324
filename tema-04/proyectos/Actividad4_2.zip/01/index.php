<?php
    /*
        Controlador: index.php


    */

    // Cargamos la clase
    include 'class/class.calculadora.php';

    // Cargamos la vista
    include 'views/viewIndex.php';
?>