<?php
    // Controlador nuevo.php
    // Cargara el formulario de introducción de nuevo artículo

    // Cargamos las clases correspondientes
    include 'class/class.alumno.php';
    include 'class/class.arrayAlumnos.php';

    // añadimos el modelo donde tenemos lo datos definidos
    include 'models/modelNuevo.php';

    // cargamos la vista
    include 'views/viewNuevo.php';
?>