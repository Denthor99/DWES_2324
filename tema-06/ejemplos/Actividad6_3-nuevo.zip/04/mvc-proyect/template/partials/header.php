<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi-pc-display"></i>
    <span class="fs-3">Proyecto 5.2- Gestión de Alumnos</span>
</header>