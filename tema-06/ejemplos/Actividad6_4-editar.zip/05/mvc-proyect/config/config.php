<?php
# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'fp');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');

// Ruta absoluta
define('URL','http://localhost/dwes/tema-06/ejemplos/05/mvc-proyect/');

?>