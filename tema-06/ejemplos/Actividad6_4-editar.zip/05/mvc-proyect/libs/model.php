<?php

    class Model {

        function __construct() {
            // Creamos un objeto de la clase Database
            $this->db = new Database();

        }

    }

?>