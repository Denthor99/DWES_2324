<?php
# Configuración básica aplicación MVC

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');

# Ruta absoluta
define('URL', 'http://localhost/DWES/tema-06/proyectos/01/');

?>